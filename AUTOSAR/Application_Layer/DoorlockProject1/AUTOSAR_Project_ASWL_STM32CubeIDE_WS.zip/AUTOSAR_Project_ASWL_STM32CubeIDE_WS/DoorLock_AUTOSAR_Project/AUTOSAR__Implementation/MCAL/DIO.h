/*
 * DIO.h
 *
 *  Created on: May 16, 2023
 *      Author: Manal
 */

#ifndef MCAL_DIO_H_
#define MCAL_DIO_H_

#include "stm32f103x8_gpio_driver.h"

unsigned char DIO_ReadChannel(unsigned char ID);
void DIO_WriteChannel(unsigned char ID ,unsigned char Level );

//DIO IDs(PORTA)
#define DIO_DOOR GPIO_PIN_3
#define LED_ID GPIO_PIN_7

//PORT used
#define GPIO_PORT_Used GPIOA

#endif /* MCAL_DIO_H_ */
