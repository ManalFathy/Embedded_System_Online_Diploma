/*
 * DIO.C
 *
 *  Created on: May 16, 2023
 *      Author: Manal
 */
#include"DIO.h"

unsigned char DIO_ReadChannel(unsigned char ID)
{

	return (MCAL_GPIO_ReadPin(GPIO_PORT_Used, ID));
}
void DIO_WriteChannel(unsigned char ID ,unsigned char Level )
{
	MCAL_GPIO_WritePin(GPIO_PORT_Used, ID, Level);
}
